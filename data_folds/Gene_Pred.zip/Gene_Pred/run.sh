#!/bin/bash
#Commands for the BINF90004 practical "Gene prediction in non-model organisms" on 10.08.2020
#Dr Andreas Stroehlein 

#For each step, check the output file (your intermediate results) using the "less", "wc -l", "head", "tail", commands to confirm your analysis has
# worked, and to get an appreciation for the output format

# blat align the RNAseq reads to the genome
# we define the step size with which we are walking along the reference sequence to try and find a match and initiate an alignment
# -tileSize=N sets the size of match that triggers an alignment.
#                Usually between 8 and 12
#                Default is 11 for DNA and 5 for protein.
#    -stepSize=N spacing between tiles. Default is tileSize.
blat -noHead -stepSize=5 -minIdentity=93 genome.fa RNAseq-hitreadssub.fa ali.psl
# Loaded 1000000 letters in 1 sequences
# Searched 6279300 bases in 41862 sequences
#Output check: less ali.psl


# filter alignments for alignment quality, uniqueness and pairedness, if applicable. Also sort input on name
# option: -uniq   take only best match and only, when second best is much worse (default false) 
sort -k 10,10 ali.psl | filterPSL.pl --uniq  > ali.f.psl
# processed line 1
#         filtered:
# ----------------:
# percent identity: 7048
# coverage        : 3569
# uniq            : 34341
# command line: --uniq
#Output check: less ali.psl

# Sort alignments by target sequence and within target sequence by position for further processing
cat ali.f.psl | sort -n -k 16,16 | sort -s -k 14,14 > ali.fs.psl


# When predicting genes,
#     AUGUSTUS can incorporate these hints,
#     which will change the likelihood of gene structure candidates.
#     It will tend to predict gene structures that are in agreement with the hints.

# Each exonpart hint specifies an interval that is likely to be exonic. We take the local coverage depth into account. For the purpose of exonpart hint generation and visualization we first summarize the alignments to a coverage depth function in wiggle format. Wiggle format (.wig) is a format of the UCSC Genome Browser.
aln2wig -f ali.fs.psl > cov.wig

# Now generate the exonpart hints with
cat cov.wig | wig2hints.pl --width=10 --margin=10 --minthresh=2 --minscore=4 --prune=0.1 --src=W --type=exonpart --UCSC=unstranded.track --radius=4.5 --pri=4 --strand="." > hints.ep.gff
    # --width=n         Default: 40
    # --margin=n        Default: 20
    # --minthresh=p     Default: 0.4 horizontal cutoff for determining intervals
    # --minscore=p      Default: 0.4 consider only intervals with an average score at least this high
    # --type=s          Default: print this in the third column (default:"CDSpart")
    # --pri=n           print priority n in last column
    # --radius=n        length of hint interval is 2*radius+1
    # --strand=s        Default: "." print this in the strand column
    # --prune=f         Default: 0 (off). Remove boundary areas that have coverage less than f*100% of the average over the island
    # --src=s           Default: "X" print src=s in the last column
    # --UCSC=s          Filename for track of UCSC genome browser custom track



# Evidence about introns is collected from spliced alignments. The crucial data is the exact intron boundaries and the multiplicity of the intron, i.e. the absolute number of reads that span the intron.
blat2hints.pl --intronsonly --in=ali.fs.psl --out=hints.introns.gff
#processed line 14001

#With the word hint we are referring to an uncertain local piece
#of information about the gene structure of the input sequence such
#as a likely position of a signal or a likely stretch of coding sequence.

# Concatenate all hints
cat hints.introns.gff hints.ep.gff > hints.gff


#Run Augustus, this will run for a while, take a break, get yourself a coffee
augustus --species=hcon4 --UTR=off --extrinsicCfgFile=extrinsic.EW.cfg --alternatives-from-evidence=true --hintsfile=hints.gff --allow_hinted_splicesites=atac genome.fa  > augustus_out.txt
#exonpart: src=W
#    exonpart: part of an exon in the biological sense. The bonus applies only
#              to exons that contain the interval from the hint. Just
#              overlapping means no bonus at all. The malus applies to every
#              base of an exon. Therefore the malus for an exon is exponential
#              in the length of an exon: malus=exonpartmalus^length.
#            Therefore the malus should be close to 1, e.g. 0.99.
#hints from transcriptome coverage (“wiggle” track)

#intron: src=E(ST)
#      intron: An intron gets the bonus if and only if it is exactly as in the hint.

#--allow_hinted_splicesites=atac allows AUGUSTUS to also predict those (rare) introns that start with AT and end
#with AC in addition to the GT/AG and GC/AG introns that are allowed by default.
#With above command, no alternative splicing is predicted.
#However, the option --alternatives-from-evidence=on makes AUGUSTUS report alternative tran- scripts when they are suggested by hint

# individual_liability: Only unsatisfiable hints are disregarded. By default this flag is not set
# and the whole hint group is disregarded when one hint in it is unsatisfiable.

# Each individual hint contains only local information.
# However, in the presence of alternative splicing or, in general, when the transcript alignments ‘contradict’ each other,
# an alignment usually contains more information than the set of independent hints derived from it.
# It also indicates that these hints belong to the same transcript.
# Therefore, we allow that the hints are grouped such that all hints
# from one group are thought to belong to the same transcript.
# All hints that are derived from a single (native or TRANSMAP) alignment are grouped together.
# Hints from different alignments belong to different groups.

# In an initial step of the AUGUSTUS algorithm the compatibility
# of all hint groups with each other is determined.
# Two hint groups are considered compatible if and only if
# there is a possible single-transcript gene structure that
# is compatible with both hint groups. In particular, alignments
# suggesting alternative splice variants of a gene yield incompatible hint groups.
# Also, alignments suggesting a gene contained in an intron of another gene or
# overlapping genes on opposite strands yield incompatible hint groups. 

#    Reformat the Augustus output into 3 files
#    augustus_prediction.gff, gene annotation file
#    augustus_prediction.pep, a fasta file of the predicted proteins
#    augustus_prediction.csv, a tab delimited table with gene prediction statistics for each gene/transcript
perl augustus_format.pl augustus_out.txt


## Visualise the genome and add prediction tracks using IGV viewer
igv -g genome.fa

#BLAST
blastp -db ./BLAST/pracBLAST_DB_nr_noHc.fasta -query augustus_prediction.pep -evalue 1E-5 -max_target_seqs 50 -outfmt 6 -out augustus_prediction.blast6

#./BLAST/ contains BLASTinfo.tsv (tab-separated file), which lists GI (column 1), protein description (column 2) and the species name (column 3) for each hit.
#head -4 BLASTinfo.tsv
#1000200785     hypothetical protein RP20_CCG015650     Aedes albopictus
#1000211152     hypothetical protein RP20_CCG022284     Aedes albopictus
#1000211248     hypothetical protein RP20_CCG021245     Aedes albopictus
#1000212262     hypothetical protein RP20_CCG017111     Aedes albopictus

#Use this file to summarise your BLAST results (augustus_prediction.blast6)
#Think about ways to visualise your results (we will go through a few examples using bash commands and R)
awk -F"\t" 'BEGIN{while(getline < "./BLAST/BLASTinfo.tsv"){descr[$1]=$2; spec[$1]=$3}}{split($2,id,/\|/); print $1"\t"id[1]"\t"$0"\t"descr[id[1]]"\t"spec[id[1]]}' augustus_prediction.blast6 | cut -f1,2,5- > blast_species_descr.tsv
awk '{if($0 ~ /^>/){id=$0; len[id]=""}else{len[id]=len[id]+length($0)}}END{for(i in len){print i"\t"len[i]}}' augustus_prediction.pep | sed 's/^>//' > qlen.tsv
awk -F"\t" 'BEGIN{while(getline < "qlen.tsv"){len[$1]=$2}}{print $0"\t"len[$1]}' blast_species_descr.tsv > tmp; mv tmp blast_species_descr.tsv

#We now use HMMER, a program to detect functional protein domains in protein sequences by means of hidden Markov models (HMMs)
#More info on the program: http://eddylab.org/software/hmmer/Userguide.pdf
#We will search the protein sequences against an existing HMM database (HMMsubsetHc.hmm), a database of PFAM profiles (https://pfam.xfam.org/) present in H. contortus proteins
#First we have to index the database so that it can be searched quickly
hmmpress HMMsubsetHc.hmm
# Working...    done.
# Pressed and indexed 3874 HMMs (3874 names and 3874 accessions).
# Models pressed into binary file:   HMMsubsetHc.hmm.h3m
# SSI index for binary model file:   HMMsubsetHc.hmm.h3i
# Profiles (MSV part) pressed into:  HMMsubsetHc.hmm.h3f
# Profiles (remainder) pressed into: HMMsubsetHc.hmm.h3p
#We can see that our database contains 3874 models against which all protein sequences will be searched

# -o <f> Direct the main human-readable output to a file <f> instead of the default stdout. In our case we will direct this output to /dev/null, which means it will be discarded and we only keep the more concise output file
# --domtblout <f> Save a simple tabular (space-delimited) file summarizing the per-domain output, with one data line per homologous domain detected in a query sequence for each homologous model.

hmmscan -o /dev/null --domtblout hmmer_out.domtbl HMMsubsetHc.hmm augustus_prediction.pep

#Let's have a look at our output file
less hmmer_out.domtbl
#Let's see how many entries this file has minus the headers of the columns. We will remove the headers by excluding all lines starting with a "#" first, using grep -v
grep -v "^#" hmmer_out.domtbl | wc -l
#122

#The output file has the following columns
#For description of each column, see page 71 of http://eddylab.org/software/hmmer/Userguide.pdf
# 1   target name
# 2   accession
# 3   tlen
# 4   query name
# 5   accession
# 6   qlen
# 7   full sequence E-value
# 8   full sequence score
# 9   full sequence bias
# 10  this domain \#
# 11  this domain of
# 12  this domain c-Evalue
# 13  this domain i-Evalue
# 14  this domain score
# 15  this domain bias
# 16  hmm coord from
# 17  hmm coord to
# 18  ali coord from
# 19  ali coord to
# 20  env coord from
# 21  env coord to
# 22  acc
# 23  description of target

#Now let's only select the columns we are interested in and replace the " " column separators with tabs, for easy loading into Rstudio after
grep -v "^#" hmmer_out.domtbl | sed 's/ \+/\t/g' | sed 's/\t/ /g23' | cut -f1-4,6,7,10,11,16-19,22,23 > hmmer_out.tsv

# (1) target name: The name of the target profile.
# (2) target accession: Accession of the target profile
# (3) tlen: Length of the target profile, in residues. This (together with the query length) is useful for interpreting where the domain coordinates (in subsequent columns) lie in the sequence.
# (4) query name: Name of the query sequence.
# (6) qlen: Length of the query sequence, in residues.
# (7) E-value: E-value of the overall sequence/profile comparison (including all domains).
# (10) #: This domain’s number (1..ndom).
# (11) of: The total number of domains reported in the sequence, ndom.
# (16) from (hmm coord): The start of the MEA alignment of this domain with respect to the profile, numbered 1..N for a profile of N consensus positions.
# (17) to (hmm coord): The end of the MEA alignment of this domain with respect to the profile, numbered 1..N for a profile of N consensus positions.
# (18) from (ali coord): The start of the MEA alignment of this domain with respect to the sequence, numbered 1..L for a sequence of L residues.
# (19) to (ali coord): The end of the MEA alignment of this domain with respect to the sequence, numbered 1..L for a sequence of L residues.
# (22) acc: The mean posterior probability of aligned residues in the MEA alignment; a measure of how reliable the overall alignment is (from 0 to 1, with 1.00 indicating a completely reliable alignment according to the model).
# (23) description of target: The remainder of the line is the target’s description line, as free text.

#Now open rstudio in your container and start using the below commands (these are just examples)
#to explore the data and protein annotation

###R commands, these will not run in your shell prompt, they need to be run in Rstudio
library(tidyverse)

#Read in the augustus prediction file
s_sup <- read_tsv(file = "augustus_prediction.csv") %>% separate(1, c("gene", "transcript"), sep = "\\.")

#Rename columns and select only columns we need
colnames(s_sup)[3] <- "support"
s_sup <- select(s_sup, 1:3,9)
colnames(s_sup)[4] <- "incompatible"


#Plot number and extent of transcript support by hints
s_sup %>%
  group_by(gene) %>%
  summarise(support = max(support)) %>%
  ggplot(aes(x = support)) +
  geom_histogram(binwidth = 10) +
  theme_minimal() +
  xlab("% of transcript supported by hints") +
  ylab("Count")

#Plot number of incompatible hint groups per transcript against % of support by hints
s_sup %>%
  ggplot(aes(x = support, y = incompatible, size = 2)) +
  geom_point() +
  theme_minimal() +
  xlab("% of transcript supported by hints") +
  ylab("Number of incompatible hint groups") +
  guides(size = "none")

#Read in blast results
blast <- read_tsv("blast_species_descr.tsv", col_names = c("qseqid", "sseqid", "pident", "length", "mismatch", "gapopen", "qstart", "qend", "sstart", "send", "evalue", "bitscore", "description", "species", "qlen"))

#Plot based on which related species the protein sequences have been annotated
blast %>%
select(species) %>%
group_by(species) %>%
count() %>%
arrange(desc(n)) %>% 
head(10) %>% 
ggplot(aes(x = species, y = n)) + 
geom_bar(stat = "identity") + 
theme_minimal() + xlab("Species") + 
ylab("Count") + 
theme(axis.text.x = element_text(angle = 60, hjust = 1))

#Read in PFAM HMM search results
pfam <- read_tsv("hmmer_out.tsv", col_names = c("targetName", "accession", "tlen", "queryName", "qlen", "eval", "ndom", "totalDom", "hmmStart", "hmmEnd", "aliStart", "aliEnd", "accuracyPP", "description"))

#Count occurrences of individual PFAM accession numbers
pfam %>% group_by(accession) %>% count() %>% arrange(desc(n))

#Let's check what the description is for the most commonly occurring domain
pfam %>% filter(accession == "PF00078.28") %>% select(description) %>% distinct() %>% pull()

#Calculate the percentage of the protein sequence that is covered by the HMM domain model hit
cov <- pfam %>% select(queryName, qlen, aliStart, aliEnd) %>%
  rowwise() %>%
  mutate(cov = list(c(rep(0,aliStart-1), rep(1, aliEnd-(aliStart-1)), rep(0, qlen-aliEnd)))) %>%
  group_by(queryName,qlen) %>%
  summarise(collapse = list(reduce(.x = cov, .f = `+`))) %>%
  unnest() %>% 
  filter(collapse > 0) %>%
  mutate(collapse = 1) %>% 
  group_by(queryName,qlen) %>%
  summarise(cov = sum(collapse)) %>% 
  mutate(cov = (cov/qlen)*100)
# You will get this warning, which can be ignored
# Warning message:
# Grouping rowwise data frame strips rowwise nature 

#Let's plot all proteins and the percentage of their sequence that is covered by domain annotation, in descending order
cov %>% ggplot(aes(x = reorder(queryName, desc(cov)), y = cov)) +
  geom_histogram(stat = "identity") +
  theme_minimal() +
  xlab("Protein identifier") +
  ylab("% of sequence covered by Pfam annotation") +
  theme(axis.text.x = element_text(angle = 60, hjust = 1))
# You will get this warning, which can be ignored
#Warning: Ignoring unknown parameters: binwidth, bins, pad

#Calculate the percentage of the protein sequence that is covered by the BLAST hit
  cov_blast <- blast %>% select(qseqid, qlen, qstart, qend) %>%
  rowwise() %>%
  mutate(cov = list(c(rep(0,qstart-1), rep(1, qend-(qstart-1)), rep(0, qlen-qend)))) %>%
  group_by(qseqid, qlen) %>%
  summarise(collapse = list(reduce(.x = cov, .f = `+`))) %>%
  unnest() %>% 
  filter(collapse > 0) %>%
  mutate(collapse = 1) %>% 
  group_by(qseqid, qlen) %>%
  summarise(cov_blast = sum(collapse)) %>% 
  mutate(cov_blast = (cov_blast/qlen)*100)
# You will get this warning, which can be ignored
# Warning message:
# Grouping rowwise data frame strips rowwise nature 

#Let's plot all proteins and the percentage of their sequence that is covered by the BLAST hit, in descending order
  cov_blast %>% ggplot(aes(x = reorder(qseqid, desc(cov_blast)), y = cov_blast)) +
  geom_histogram(stat = "identity") +
  theme_minimal() +
  xlab("Protein identifier") +
  ylab("% of sequence covered by blast hits") +
  theme(axis.text.x = element_text(angle = 60, hjust = 1))
# You will get this warning, which can be ignored
#Warning: Ignoring unknown parameters: binwidth, bins, pad

#Let's combine the results from BLAST and PFAM and see if coverage from the two methods correlates
full_join(cov, cov_blast, by=c("queryName"="qseqid")) %>%
  mutate(cov = replace_na(cov, 0)) %>% 
  mutate(cov_blast = replace_na(cov_blast, 0)) %>% 
  select(-qlen.x,-qlen.y) %>%
  rename(cov_ipro = cov) %>%
  mutate(cov_blast = if_else(is.na(cov_blast), 0, cov_blast)) %>%
  ggplot(aes(x = cov_ipro, y = cov_blast)) +
  geom_point(size = 5) +
  coord_fixed(1) +
  xlim(0,100) +
  ylim(0,100) +
  theme_minimal() +
  xlab("% sequence coverage by Pfam domains") +
  ylab("% sequence coverage by blastp")
