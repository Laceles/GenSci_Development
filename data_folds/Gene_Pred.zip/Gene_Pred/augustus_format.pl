#!/usr/bin/perl -w
#
# Script to read in read in the output from Augustus gene finder and format
# for Neils tutorial students
#
# Usage: augustus_format.pl augustus_output_file
#
# For Neil
#
# Ross Hall May, 2018
#

use strict;
use Data::Dumper;
 
if (@ARGV != 1) {
	print STDERR "augustus_format.pl augustus_output_file\n";
	exit(1);
}

my $aufile = shift;

# Read in the gene prediction file
open(GFILE,$aufile) || &ErrorMessage("Cannot read file ". $aufile);
my @garray = <GFILE>;

## Predicted genes for sequence number 1 on both strands
## start gene g1
#hcontortus_7_chrX_Celeg_Tb-3    AUGUSTUS        gene    333     1396    0.16    -       .       g1
#hcontortus_7_chrX_Celeg_Tb-3    AUGUSTUS        transcript      333     1396    0.16    -       .       g1.t1
#hcontortus_7_chrX_Celeg_Tb-3    AUGUSTUS        stop_codon      333     335     .       -       0       transcript_id "g1.t1"; gene_id "g1";
#hcontortus_7_chrX_Celeg_Tb-3    AUGUSTUS        intron  821     915     0.74    -       .       transcript_id "g1.t1"; gene_id "g1";
#hcontortus_7_chrX_Celeg_Tb-3    AUGUSTUS        CDS     333     820     0.24    -       2       transcript_id "g1.t1"; gene_id "g1";
#hcontortus_7_chrX_Celeg_Tb-3    AUGUSTUS        CDS     916     1396    0.8     -       0       transcript_id "g1.t1"; gene_id "g1";
#hcontortus_7_chrX_Celeg_Tb-3    AUGUSTUS        start_codon     1394    1396    .       -       0       transcript_id "g1.t1"; gene_id "g1";
## protein sequence = [MVSALDATGAVLPAVNGIGAVVPAVDDTGGAMDDTRAVVPAVNGTGEVVPAVDDTGAVLPAVDATRDMVSALDATGAV
## VPAVNGIGAVVPAVDDTGGAVDDTRAVLPAVDGIGAVVPAVDDTGGAMDDTRAVVPAVNGIGAVVPAVDGIGEVVPTVDDTGVNGTGEVVPTVDDTGG
## AVDDTGGAVDDTRAVLPAVDDTGGAVDDTRAVLPAVDGIGAVVPAVNGTGEVVPTVDDTGGAVDDTGGAVDDTRAVVPAVNGTGEVVPALDGTGEVVP
## AVDGIGAVVPAVDGIGEVVPTVDDTGGAVDDTGRWCPPWTPPGRWCPQ]
## Evidence for and against this transcript:
## % of transcript supported by hints (any source): 0
## CDS exons: 0/2
## CDS introns: 0/1
## 5'UTR exons and introns: 0/0
## 3'UTR exons and introns: 0/0
## hint groups fully obeyed: 0
## incompatible hint groups: 0
## end gene g1
####

	
open(GFFILE,">augustus_prediction.gff") || &ErrorMessage("Cannot create augustus_prediction.gff");
open(PROTFILE,">augustus_prediction.pep") || &ErrorMessage("Cannot create augustus_prediction.pep");
open(INFOFILE,">augustus_prediction.csv") || &ErrorMessage("Cannot create augustus_prediction.csv");
	
# Read through the output until the annotation starts
my $flag = 0;
my $gfflag = 0;
my $protflag = 0;
my $infoflag = 0;
my $protstr = "";
my $gname;
my $transcriptnum;
my %infohash;
my $trname;
my @trarray;
foreach my $line (@garray) {

	chomp($line);
		
	if ($line =~ /# Predicted genes for sequence/) {
		$flag = 1;
		next;
	}
	
	next if (!$flag);
	
	if ($line =~ /# start gene/) {
		my @fa = split(/ /,$line);
		$gname = $fa[3];
		$gfflag = 1;
		$transcriptnum = 0;
		next;
	}
	if ($line =~ /# protein sequence/) {
		$protflag = 1;
		$gfflag = 0;
	}
	if ($line =~ /# Evidence for and against this transcript:/) {
		# Finished capturing the protein sequence, not collect prediction stats

		my ($tag,$val) = split(/:/,$line);
		$tag = substr($tag,2);
		$val =~ s/ //g;
		
		$transcriptnum++;
		$trname= $gname . ".t" . $transcriptnum;
		push(@trarray,$trname);
		
		# We have the protein sequence now, print it to the PROTFILE
		print PROTFILE ">" . "$gname" . ".t" . $transcriptnum . "\n";
		my $i=0;
		while (($i+60)<length($protstr)) {
			print PROTFILE substr($protstr,$i,60) . "\n";
			$i+=60;
		} 
		print PROTFILE substr($protstr,$i,length($protstr)-$i) . "\n"; 	
		$infoflag = 1;
		if (!exists($infohash{$trname})) {
			my %trec;
			$infohash{$trname} = \%trec;
		}	
		if ($val ne "") {
			$infohash{$trname}->{$tag} = $val;
		}	
			
		$protflag = 0;
		next;
	}
	if ($line !~ /^#/ && $infoflag) {
		$infoflag = 0;
		$gfflag = 1;
	}	
		
	
	if ($line =~ /# end gene/) {
		$infoflag = 0;
		next;
	}
	
	if ($gfflag) {
		print GFFILE "$line\n";
	}				
	if ($protflag) {
		# In the protein sequence - keep building up $protstr
		if ($line =~ /# protein sequence/) {
			$protstr = substr($line,index($line,"[")+1);
			if($line =~ /\]/) {
				$protstr = substr($protstr,0,index($protstr,"]"));
			}	
			
		} elsif ($line =~ /\]/) {
			$protstr .= substr($line,2,index($line,"]")-2);
		} else {
			$protstr .= substr($line,2);
		}		
	}
	if ($infoflag) {
		my ($tag,$val) = split(/:/,$line);
		$tag = substr($tag,2);
		$val =~ s/ //g;
		$tag =~ s/^[ \t]*//g;
		if ($tag !~ /^W/ && $tag !~ /^E/) {
			$infohash{$trname}->{$tag} = $val;
		}	
	}	
	
}

# Get all of the column headings
my %headhash;
foreach my $tname (sort(keys(%infohash))) {
	my $hptr = $infohash{$tname};
	foreach my $tag (keys(%{$hptr})) {
		$headhash{$tag} = 1;
	}
}

# store column headings
my %colhash;
my $colnum = 0;
foreach my $h (sort(keys(%headhash))) {
	$colhash{$colnum} = $h;
	$colnum++
}

# Print the column headings to the INFOFILE
print INFOFILE "Transcript";
for (my $i=0;$i<$colnum;$i++) {
	print INFOFILE "\t" . $colhash{$i};
}
print INFOFILE "\n";	

# Print the column data to the INFOFILE
foreach my $tname (@trarray) {
	my $hptr = $infohash{$tname};
	print INFOFILE "$tname";
	for (my $i=0;$i<$colnum;$i++) {
		print INFOFILE "\t" . $hptr->{$colhash{$i}};
	}
	print INFOFILE "\n";
}		

	
sub ErrorMessage {
	my $msg = shift;
	print STDERR "Fatal error: $msg\n";
	exit(1);	
}	
